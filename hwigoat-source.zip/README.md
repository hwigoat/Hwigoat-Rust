# Hwigoat Rust 1.0.2 Public Beta - Window gestures and CI

Windows 10/11 x64. Rust + Tao 0.38.0 / Wry 0.58.2 + Chromium WebView2. Go installer embeds the precompiled Rust executable. No Rust/C++ toolchain on the end user's PC; WebView2 may require internet and installation.

## Changes
- Double-click the empty top tab-strip area to maximize or restore. Click alone does not start a native window move. Drag begins after a 5 CSS-pixel movement; tabs/buttons remain ordinary controls. Native Windows frame fallback remains available.
- Reserved at least 48 CSS pixels for window dragging. Existing window controls, monochrome UI, feedback channel, user shortcuts and memory policies remain.
- Version 1.0.2 in Cargo metadata, installer, UI and Windows executable resources.
- Existing installer backs up and patches known executable paths, checks the installed hash and actual isolated rendering/version marker, then attempts normal-profile launch. It does not delete the profile. Arbitrarily copied executables and custom shortcuts outside known paths are not managed; rollback is best effort, not an atomic multi-file transaction.

## Build and delivery
Upload `hwigoat-source.zip` to the root of https://github.com/hwigoat/Hwigoat-Rust (no extraction). GitHub Actions compiles the Rust executable, runs Rust/Go and mocked Chromium tests, embeds the binary into the Windows installer and produces an artifact with SHA-256 and Cargo.lock. `prebuilt.exe` is deliberately absent from the source archive. A Windows runtime and installation smoke check on a real test PC remains mandatory before public release. Draft release workflow is optional and requires a manual dispatch. Publishing a draft is a separate developer action.

No background update agent, signed update manifest or automatic patch distribution is included. Existing users must manually install this version. Do not distribute unsigned builds as production software. Do not put signing keys or Discord tokens into this public repository.

## Tests
Mocked Chromium regression tests include actual mouse click/double-click/drag events and validate IPC, not native Windows window movement. Linux Go tests can run with a temporary placeholder prebuilt.exe (never distribute an installer built using a placeholder). Windows native Rust compilation, WebView2 startup, snap, DPI changes and installation need real CI/test PC validation. No RAM reduction benchmark or Windows task manager group-name guarantee.

Logs: `%LOCALAPPDATA%\HwigoatRustSetup\install.log`; normal profile `%LOCALAPPDATA%\HwigoatRust`. Browser errors `%LOCALAPPDATA%\HwigoatRust-error.log`. Feedback: https://discord.com/channels/1213126669385338920/1575778721946796062
