package main

import (
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"debug/pe"
	"embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

//go:embed project/Cargo.toml project/build.rs project/src/*
var assets embed.FS

//go:embed prebuilt.exe
var prebuiltBinary []byte

const version = "1.0.2"
const target = "x86_64-pc-windows-msvc"
const rustURL = "https://static.rust-lang.org/rustup/dist/" + target + "/rustup-init.exe"
const vsURL = "https://aka.ms/vs/17/release/vs_buildtools.exe"
const webURL = "https://go.microsoft.com/fwlink/p/?LinkId=2124703"

var out io.Writer = os.Stdout
var client = &http.Client{Timeout: 20 * time.Minute, CheckRedirect: func(req *http.Request, via []*http.Request) error {
	if req.URL.Scheme != "https" || len(via) >= 12 {
		return errors.New("unsafe download redirect")
	}
	return nil
}}

func logf(f string, a ...any) { fmt.Fprintf(out, f+"\n", a...) }
func envWith(base []string, kv ...string) []string {
	for _, x := range kv {
		k, _, _ := strings.Cut(x, "=")
		res := base[:0:0]
		for _, v := range base {
			n, _, _ := strings.Cut(v, "=")
			if !strings.EqualFold(n, k) {
				res = append(res, v)
			}
		}
		base = append(res, x)
	}
	return base
}
func exists(p string) bool { f, e := os.Stat(p); return e == nil && !f.IsDir() }
func run(dir string, env []string, exe string, args ...string) error {
	logf("> %s %s", filepath.Base(exe), strings.Join(args, " "))
	c := exec.Command(exe, args...)
	c.Dir = dir
	c.Env = env
	c.Stdout = out
	c.Stderr = out
	c.Stdin = os.Stdin
	return c.Run()
}
func ps(env []string, script string) error {
	return run("", env, "powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", script)
}
func download(url, dest string) error {
	logf("Downloading %s", url)
	r, e := client.Get(url)
	if e != nil {
		return e
	}
	defer r.Body.Close()
	if r.StatusCode != 200 {
		return fmt.Errorf("HTTP %s", r.Status)
	}
	f, e := os.Create(dest)
	if e != nil {
		return e
	}
	n, e := io.Copy(f, io.LimitReader(r.Body, 512<<20))
	ce := f.Close()
	if e != nil {
		return e
	}
	if ce != nil {
		return ce
	}
	if n >= 512<<20 {
		return errors.New("download too large")
	}
	if r.ContentLength >= 0 && r.ContentLength != n {
		return errors.New("incomplete download")
	}
	return nil
}
func verifyHash(p, hash string) error {
	fields := strings.Fields(hash)
	if len(fields) == 0 || len(fields[0]) != 64 {
		return errors.New("invalid official checksum")
	}
	f, e := os.Open(p)
	if e != nil {
		return e
	}
	defer f.Close()
	h := sha256.New()
	if _, e = io.Copy(h, f); e != nil {
		return e
	}
	if !strings.EqualFold(fields[0], hex.EncodeToString(h.Sum(nil))) {
		return errors.New("SHA-256 mismatch")
	}
	return nil
}
func verifyMicrosoft(p string) error {
	return ps(envWith(os.Environ(), "HWIGOAT_VERIFY="+p), `$ErrorActionPreference='Stop'; $s=Get-AuthenticodeSignature -LiteralPath $env:HWIGOAT_VERIFY; if($s.Status -ne 'Valid' -or $s.SignerCertificate.Subject -notmatch 'Microsoft Corporation'){throw 'Microsoft signature verification failed'}`)
}
func installedVS() bool {
	base := os.Getenv("ProgramFiles(x86)")
	if base == "" {
		return false
	}
	vs := filepath.Join(base, "Microsoft Visual Studio", "Installer", "vswhere.exe")
	if !exists(vs) {
		return false
	}
	b, e := exec.Command(vs, "-latest", "-products", "*", "-requires", "Microsoft.VisualStudio.Component.VC.Tools.x86.x64", "-property", "installationPath").Output()
	return e == nil && strings.TrimSpace(string(b)) != ""
}
func webInstalled() bool {
	const key = `Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}`
	for _, k := range []string{`HKCU\` + key, `HKLM\` + key} {
		for _, v := range []string{"/reg:32", "/reg:64"} {
			b, e := exec.Command("reg.exe", "query", k, "/v", "pv", v).Output()
			if e == nil {
				for _, line := range strings.Split(string(b), "\n") {
					a := strings.Fields(line)
					if len(a) >= 3 && a[0] == "pv" && a[2] != "0.0.0.0" {
						return true
					}
				}
			}
		}
	}
	return false
}
func copyAssets(root string) error {
	return fs.WalkDir(assets, "project", func(path string, d fs.DirEntry, e error) error {
		if e != nil {
			return e
		}
		rel := strings.TrimPrefix(strings.TrimPrefix(path, "project"), "/")
		dst := filepath.Join(root, filepath.FromSlash(rel))
		if d.IsDir() {
			return os.MkdirAll(dst, 0755)
		}
		b, e := assets.ReadFile(path)
		if e != nil {
			return e
		}
		if old, err := os.ReadFile(dst); err == nil && bytes.Equal(old, b) {
			return nil
		}
		return os.WriteFile(dst, b, 0644)
	})
}
func smoke(exe, mark string) error {
	_ = os.Remove(mark)
	ctx, cancel := context.WithTimeout(context.Background(), 100*time.Second)
	defer cancel()
	c := exec.CommandContext(ctx, exe)
	c.Dir = filepath.Dir(exe)
	c.Env = envWith(os.Environ(), "HWIGOAT_SMOKE_FILE="+mark)
	c.Stdout = out
	c.Stderr = out
	e := c.Run()
	tracePath := strings.TrimSuffix(mark, filepath.Ext(mark)) + ".log"
	if b, err := os.ReadFile(tracePath); err == nil {
		logf("--- Browser startup trace ---\n%s--- End startup trace ---", string(b))
	} else {
		logf("No browser startup trace was created: %v", err)
	}
	if ctx.Err() != nil {
		return errors.New("browser initialization timed out (100 seconds); see startup trace above")
	}
	if e != nil {
		return fmt.Errorf("browser initialization failed: %w", e)
	}
	b, e := os.ReadFile(mark)
	if e != nil {
		return fmt.Errorf("missing browser verification marker: %w", e)
	}
	if e = verifySmokeMarker(string(b)); e != nil {
		return e
	}
	return nil
}

func verifySmokeMarker(marker string) error {
	normalized := strings.ReplaceAll(marker, "\r\n", "\n")
	if normalized != "UI IPC and content DOM verified\nversion="+version+"\n" {
		return fmt.Errorf("browser verification marker has wrong version or missing rendering result: %q", marker)
	}
	return nil
}
func fileHash(p string) (string, error) {
	f, e := os.Open(p)
	if e != nil {
		return "", e
	}
	defer f.Close()
	h := sha256.New()
	if _, e = io.Copy(h, f); e != nil {
		return "", e
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// Keep the existing executable path so existing shortcuts keep working.
func installDir(base string) string {
	for _, d := range []string{"", "0.5.3", "0.5.2", "0.5.1", "0.5.0"} {
		p := filepath.Join(base, d)
		if exists(filepath.Join(p, "Hwigoat Rust.exe")) {
			return p
		}
	}
	return base
}
func copyAtomic(src, dst string) error {
	in, e := os.Open(src)
	if e != nil {
		return e
	}
	defer in.Close()
	f, e := os.CreateTemp(filepath.Dir(dst), ".hwigoat-stage-*")
	if e != nil {
		return e
	}
	temp := f.Name()
	defer os.Remove(temp)
	h := sha256.New()
	_, e = io.Copy(io.MultiWriter(f, h), in)
	if e == nil {
		e = f.Sync()
	}
	ce := f.Close()
	if e != nil {
		return e
	}
	if ce != nil {
		return ce
	}
	if e = verifyHash(temp, hex.EncodeToString(h.Sum(nil))); e != nil {
		return e
	}
	return moveReplace(temp, dst)
}
func replaceBinary(src, dst string) error {
	if !exists(src) {
		return errors.New("tested binary missing")
	}
	if exists(dst) {
		old, e := fileHash(dst)
		if e != nil {
			return e
		}
		next, e := fileHash(src)
		if e != nil {
			return e
		}
		if old == next {
			return nil
		}
		if e := copyAtomic(dst, dst+".previous"); e != nil {
			return fmt.Errorf("backup failed: %w", e)
		}
	}
	if e := copyAtomic(src, dst); e != nil {
		return fmt.Errorf("patch failed; close the browser before retrying: %w", e)
	}
	return nil
}

// Include older known installation paths so existing pinned shortcuts do not run stale versions.
func installTargets(base string) []string {
	primary := filepath.Join(installDir(base), "Hwigoat Rust.exe")
	result := []string{primary}
	for _, d := range []string{"", "0.5.3", "0.5.2", "0.5.1", "0.5.0"} {
		p := filepath.Join(base, d, "Hwigoat Rust.exe")
		if !strings.EqualFold(p, primary) && exists(p) {
			result = append(result, p)
		}
	}
	return result
}

// Back up each changed executable before publishing it. If any validation fails,
// restore only the paths changed by this transaction. Identical files are untouched.
func patchTransaction(src string, paths []string, validate func() error) (err error) {
	if len(paths) == 0 {
		return errors.New("no patch targets")
	}
	hash, err := fileHash(src)
	if err != nil {
		return err
	}
	type change struct {
		path    string
		existed bool
	}
	var changed []change
	defer func() {
		if err == nil {
			return
		}
		for i := len(changed) - 1; i >= 0; i-- {
			c := changed[i]
			var re error
			if c.existed {
				re = copyAtomic(c.path+".previous", c.path)
			} else {
				re = os.Remove(c.path)
			}
			if re != nil {
				err = errors.Join(err, fmt.Errorf("ROLLBACK FAILED %s: %w", c.path, re))
			} else {
				logf("Rolled back: %s", c.path)
			}
		}
	}()
	for _, p := range paths {
		if err = os.MkdirAll(filepath.Dir(p), 0755); err != nil {
			return err
		}
		had := exists(p)
		if had {
			old, e := fileHash(p)
			if e != nil {
				return e
			}
			if old == hash {
				logf("Already current: %s", p)
				continue
			}
		}
		if err = replaceBinary(src, p); err != nil {
			return err
		}
		changed = append(changed, change{p, had})
		if err = verifyHash(p, hash); err != nil {
			return err
		}
	}
	return validate()
}
func reuseLock(root, proj string) error {
	dst := filepath.Join(proj, "Cargo.lock")
	for _, p := range []string{dst, filepath.Join(root, "build-v0.5.3", "Cargo.lock"), filepath.Join(root, "build-v0.5.2", "Cargo.lock")} {
		b, e := os.ReadFile(p)
		if os.IsNotExist(e) {
			continue
		}
		if e != nil {
			return e
		}
		lines := strings.Split(string(b), "\n")
		for i := 0; i+1 < len(lines); i++ {
			if strings.TrimSpace(lines[i]) == `name = "hwigoat-rust"` && strings.HasPrefix(strings.TrimSpace(lines[i+1]), `version = "`) {
				lines[i+1] = `version = "` + version + `"`
				next := []byte(strings.Join(lines, "\n"))
				if old, err := os.ReadFile(dst); err == nil && bytes.Equal(old, next) {
					return nil
				}
				return os.WriteFile(dst, next, 0644)
			}
		}
		return errors.New("existing Cargo.lock has no Hwigoat package; inspect before retrying")
	}
	return nil
}

// Match only the known browser executable paths, never the shared WebView2 processes.
func browserPaths(base, root string) []string {
	paths := []string{filepath.Join(root, "target", target, "release", "hwigoat-rust.exe"), filepath.Join(root, "target", target, "debug", "hwigoat-rust.exe")}
	for _, d := range []string{"", "0.5.3", "0.5.2", "0.5.1", "0.5.0"} {
		paths = append(paths, filepath.Join(base, d, "Hwigoat Rust.exe"))
	}
	return paths
}

func closeBrowser(root string) error {
	base := filepath.Join(os.Getenv("LOCALAPPDATA"), "Programs", "Hwigoat Rust")
	paths, err := json.Marshal(browserPaths(base, root))
	if err != nil {
		return err
	}
	logf("Checking for running Hwigoat Rust windows; requesting normal close if necessary.")
	err = ps(envWith(os.Environ(), "HWIGOAT_PATHS="+string(paths)), `
$ErrorActionPreference='Stop'
$paths=@(ConvertFrom-Json -InputObject $env:HWIGOAT_PATHS)
function FindBrowser {
    $all=@(Get-Process -Name 'Hwigoat Rust','hwigoat-rust' -ErrorAction SilentlyContinue)
    foreach($p in $all){
        try { $path=$p.Path } catch { $path=$null }
        if($path -and ($paths -contains $path)){ $p }
        elseif(-not $path){ Write-Host ('Cannot inspect process PID '+$p.Id+'; close it manually if it is Hwigoat Rust.') }
        else { Write-Host ('Ignoring unrelated process PID '+$p.Id+' at '+$path) }
    }
}
$running=@(FindBrowser)
if($running.Count -eq 0){Write-Host 'No matching browser process is running.'; return}
foreach($p in $running){
    Write-Host ('Requesting normal close for PID '+$p.Id+' '+$p.Path)
    try { if(-not $p.HasExited){[void]$p.CloseMainWindow()} } catch { Write-Host $_.Exception.Message }
}
$until=[DateTime]::UtcNow.AddSeconds(20)
do {
    Start-Sleep -Milliseconds 500
    $running=@(FindBrowser)
    if($running.Count -eq 0){Write-Host 'Browser closed normally.'; return}
} while([DateTime]::UtcNow -lt $until)
foreach($p in $running){Write-Host ('Still running: PID '+$p.Id+' '+$p.Path)}
throw 'Browser did not close. Finish downloads or save work, close the listed browser process in Task Manager, then rerun the patch. No force termination performed.'
`)
	return err
}
func install(root string) error {
	if e := closeBrowser(root); e != nil {
		return e
	}
	tmp, e := os.MkdirTemp(root, "setup-")
	if e != nil {
		return e
	}
	defer os.RemoveAll(tmp)
	logf("[1/4] Checking Microsoft WebView2 Runtime")
	if !webInstalled() {
		p := filepath.Join(tmp, "WebView2Setup.exe")
		if e = download(webURL, p); e != nil {
			return e
		}
		if e = verifyMicrosoft(p); e != nil {
			return e
		}
		if e = run(tmp, os.Environ(), p, "/silent", "/install"); e != nil {
			return e
		}
		if !webInstalled() {
			return errors.New("WebView2 Runtime not detected after installation")
		}
	}
	logf("[2/4] Extracting precompiled Windows x64 browser")
	exe := filepath.Join(tmp, "hwigoat-rust.exe")
	if e = os.WriteFile(exe, prebuiltBinary, 0700); e != nil {
		return e
	}
	peFile, e := pe.Open(exe)
	if e != nil {
		return fmt.Errorf("invalid embedded Windows binary: %w", e)
	}
	machine := peFile.Machine
	peFile.Close()
	if machine != pe.IMAGE_FILE_MACHINE_AMD64 {
		return errors.New("embedded binary is not Windows x64")
	}
	logf("[3/4] Testing browser UI and local HTML rendering")
	if e = smoke(exe, filepath.Join(tmp, "smoke.ok")); e != nil {
		return e
	}
	logf("[4/4] Installing the tested binary and creating shortcuts")
	base := filepath.Join(os.Getenv("LOCALAPPDATA"), "Programs", "Hwigoat Rust")
	dest := installDir(base)
	final := filepath.Join(dest, "Hwigoat Rust.exe")
	if e = closeBrowser(root); e != nil {
		return e
	}
	paths := installTargets(base)
	logf("Primary executable: %s", final)
	for _, p := range paths {
		logf("Patch target: %s", p)
	}
	hash, e := fileHash(exe)
	if e != nil {
		return e
	}
	logf("Verified build SHA-256: %s", hash)
	e = patchTransaction(exe, paths, func() error {
		// Verify the actual installed executable, not just the compiler output.
		logf("Verifying installed browser at %s", final)
		if err := smoke(final, filepath.Join(tmp, "installed-smoke.ok")); err != nil {
			return fmt.Errorf("installed browser verification: %w", err)
		}
		for _, p := range paths {
			if err := verifyHash(p, hash); err != nil {
				return fmt.Errorf("installed hash mismatch at %s: %w", p, err)
			}
		}
		// Repoint both standard shortcuts and verify what Windows actually saved.
		if err := ps(envWith(os.Environ(), "HWIGOAT_APP="+final), `$ErrorActionPreference='Stop'; $w=New-Object -ComObject WScript.Shell; foreach($folder in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){if($folder){$path=Join-Path $folder 'Hwigoat Rust.lnk';$l=$w.CreateShortcut($path);$l.TargetPath=$env:HWIGOAT_APP;$l.Arguments='';$l.WorkingDirectory=Split-Path $env:HWIGOAT_APP;$l.IconLocation=$env:HWIGOAT_APP+',0';$l.Description='Hwigoat Rust';$l.Save();$v=$w.CreateShortcut($path);if($v.TargetPath -ne $env:HWIGOAT_APP -or $v.Arguments){throw ('Shortcut verification failed: '+$path)};Write-Host ('Verified shortcut: '+$path)}}`); err != nil {
			return err
		}
		return nil
	})
	if e != nil {
		return e
	}
	logf("PATCH VERIFIED: Hwigoat Rust %s | SHA-256 %s", version, hash)
	logf("Starting the updated browser using the normal user profile.")
	if err := launchInstalled(final, filepath.Join(tmp, "launch.ok")); err != nil {
		logf("INSTALLED, but normal startup could not be confirmed: %v", err)
		logf("The verified executable remains installed at %s. Check HwigoatRust-error.log if present.", final)
		return nil
	}
	logf("SUCCESS: Hwigoat Rust %s installed and normal-profile UI initialized. User profile preserved.", version)
	return nil
}
func launchInstalled(exe, mark string) error {
	_ = os.Remove(mark)
	c := exec.Command(exe)
	c.Dir = filepath.Dir(exe)
	c.Env = envWith(os.Environ(), "HWIGOAT_SMOKE_FILE=", "HWIGOAT_LAUNCH_MARK="+mark)
	// Remove the smoke variable altogether: Rust treats an empty value as present.
	filtered := c.Env[:0]
	for _, item := range c.Env {
		k, _, _ := strings.Cut(item, "=")
		if !strings.EqualFold(k, "HWIGOAT_SMOKE_FILE") {
			filtered = append(filtered, item)
		}
	}
	c.Env = filtered
	if err := c.Start(); err != nil {
		return err
	}
	done := make(chan error, 1)
	go func() { done <- c.Wait() }()
	ticker := time.NewTicker(250 * time.Millisecond)
	defer ticker.Stop()
	timer := time.NewTimer(45 * time.Second)
	defer timer.Stop()
	for {
		select {
		case err := <-done:
			return fmt.Errorf("browser exited before reporting readiness: %v", err)
		case <-ticker.C:
			if b, err := os.ReadFile(mark); err == nil && string(b) == "version="+version+"\nnormal profile UI IPC and content controller ready\n" {
				return nil
			}
		case <-timer.C:
			return errors.New("normal profile startup did not report readiness; browser was not terminated")
		}
	}
}
func main() {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		fmt.Println("LOCALAPPDATA is unavailable.")
		return
	}
	root := filepath.Join(base, "HwigoatRustSetup")
	if e := os.MkdirAll(root, 0755); e != nil {
		fmt.Println(e)
		return
	}
	unlock, err := acquireSetupLock(root)
	if err != nil {
		fmt.Println(err)
		_, _ = bufio.NewReader(os.Stdin).ReadString('\n')
		return
	}
	defer unlock()
	logPath := filepath.Join(root, "install.log")
	if exists(logPath) {
		_ = copyAtomic(logPath, filepath.Join(root, "install.previous.log"))
	}
	f, e := os.Create(logPath)
	if e != nil {
		fmt.Println(e)
		return
	}
	defer f.Close()
	out = io.MultiWriter(os.Stdout, f)
	logf("HWIGOAT RUST %s | Windows x64 precompiled in-place patch installer", version)
	logf("Log: %s", logPath)
	if e = install(root); e != nil {
		logf("SETUP FAILED: %v", e)
		logf("Log: %s", logPath)
		logf("Press Enter to close.")
		_, _ = bufio.NewReader(os.Stdin).ReadString('\n')
		unlock()
		os.Exit(1)
	}
	logf("Press Enter to close.")
	_, _ = bufio.NewReader(os.Stdin).ReadString('\n')
}
