//go:build windows

package main

import (
	"crypto/sha256"
	"fmt"
	"strings"
	"syscall"
	"unsafe"
)

// Mutex lifetime belongs to the process; Windows releases it even after a crash.
func acquireSetupLock(root string) (func(), error) {
	k := syscall.NewLazyDLL("kernel32.dll")
	create := k.NewProc("CreateMutexW")
	closeHandle := k.NewProc("CloseHandle")
	name, _ := syscall.UTF16PtrFromString(fmt.Sprintf(`Local\HwigoatRustSetup-%x`, sha256.Sum256([]byte(strings.ToLower(root)))))
	h, _, err := create.Call(0, 0, uintptr(unsafe.Pointer(name)))
	if h == 0 {
		return nil, fmt.Errorf("cannot acquire setup lock: %v", err)
	}
	if err == syscall.Errno(183) {
		closeHandle.Call(h)
		return nil, fmt.Errorf("another Hwigoat Rust setup is already running")
	}
	return func() { closeHandle.Call(h) }, nil
}
