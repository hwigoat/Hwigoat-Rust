"""Test browser chrome in Chromium with mocked Rust IPC (not WebView2)."""
from pathlib import Path
import os, shutil
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=shutil.which('chromium') or None, args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 1280, 'height': 820})
    errors=[]
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.evaluate('window.messages=[];window.ipc={postMessage:s=>window.messages.push(JSON.parse(s))};window.__hwigoatReadyAck=true;')
    page.set_content((Path(__file__).parent/'project/src/ui.html').read_text(encoding='utf-8'))
    state = dict(tabs=[dict(id=1,title='NAVER',url='https://www.naver.com/',private=False,sleep=False,low=False),dict(id=2,title='Example',url='https://example.com/',private=False,sleep=False,low=True)],active=1,url='https://www.naver.com/',bookmarks=[],history=[],shortcuts=[],memory_saver=True,auto_release=False,engine_groups=1,loaded=2,low_count=1,light=False,notice='',panel=False)
    def render(**changes):
        state.update(changes)
        page.evaluate('s=>window.renderState(s)', state)
    render()
    assert page.locator('body').evaluate("e=>getComputedStyle(e).backgroundColor")=='rgb(12, 12, 12)'
    assert not page.locator('#quick').is_visible()
    assert page.locator('.toolbar').bounding_box()['y'] + page.locator('.toolbar').bounding_box()['height'] == 88
    assert page.locator('#tabs .tab').count()==2
    assert page.locator('#windowControls').is_visible()
    page.locator('#feedbackButton').click()
    assert page.evaluate('messages.at(-1).action')=='feedback'
    # Real browser mouse gestures, mocked native IPC. A click must not start a drag.
    page.evaluate('messages.length=0')
    page.locator('#dragArea').click()
    assert page.evaluate('messages.length')==0
    page.locator('#dragArea').dblclick()
    assert page.evaluate('messages.map(m=>m.action)')==['window_maximize']
    render(maximized=True)
    page.evaluate('messages.length=0')
    page.locator('#dragArea').dblclick()
    assert page.evaluate('messages.map(m=>m.action)')==['window_maximize']
    render(maximized=False)
    page.evaluate('messages.length=0')
    b=page.locator('#dragArea').bounding_box(); x=b['x']+b['width']/2;y=b['y']+b['height']/2
    page.mouse.move(x,y);page.mouse.down();page.mouse.move(x+2,y);assert page.evaluate('messages.length')==0
    page.mouse.move(x+12,y,steps=4);page.mouse.move(x+20,y);page.mouse.up()
    assert page.evaluate('messages.map(m=>m.action)')==['window_drag']
    page.evaluate('messages.length=0')
    page.locator('#tabs .select').first.click()
    assert page.evaluate('messages.map(m=>m.action)')==['select']
    page.locator('#dragArea').click(button='right')
    assert page.evaluate('messages.map(m=>m.action)')==['select']
    page.locator('#maximize').click()
    assert page.evaluate('messages.at(-1).action')=='window_maximize'
    render(maximized=True)
    assert page.locator('#maximize').get_attribute('aria-label')=='이전 크기로 복원'
    render(native_frame=True)
    assert not page.locator('#windowControls').is_visible()
    render(native_frame=False,maximized=False)
    assert page.locator('.strip .brand').count()==0
    assert page.locator('#tabs').bounding_box()['x']==8
    assert page.locator('#tabs .tab').first.bounding_box()['x']==8
    page.locator('[data-a=panel]').first.click()
    assert page.evaluate('messages.at(-1).action')=='panel'
    render(panel=True)
    assert page.locator('.settings-head .emblem').is_visible()
    assert page.locator('#feedbackLink').input_value()=='https://discord.com/channels/1213126669385338920/1575778721946796062'
    diag=page.locator('#diagnostics').input_value()
    assert 'Hwigoat Rust 1.0.2 Public Beta' in diag and 'naver.com' not in diag
    page.locator('#copyDiagnostics').click()
    assert page.locator('#copyStatus').inner_text()
    page.locator('[data-mode=standard]').click()
    assert page.evaluate('messages.at(-1).value')=='standard'
    page.once('dialog',lambda d:d.dismiss())
    before=page.evaluate('messages.length')
    page.locator('[data-mode=aggressive]').click()
    assert page.evaluate('messages.length')==before
    page.once('dialog',lambda d:d.accept())
    page.locator('[data-mode=aggressive]').click()
    assert page.evaluate('messages.at(-1).value')=='aggressive'
    render(auto_release=True)
    page.locator('#releaseMinutes').select_option('3')
    assert page.evaluate('messages.at(-1).value')=='3'
    render(auto_release=False,release_minutes=10)
    page.locator('[data-a=add_shortcut]').click()
    assert page.evaluate('messages.at(-1).action')=='add_shortcut'
    page.locator('#shortcutTitle').fill('Example')
    page.locator('#shortcutUrl').fill('https://example.com/')
    page.locator('#shortcutForm button').click()
    assert page.evaluate('JSON.parse(messages.at(-1).value).title')=='Example'
    render(shortcuts=[dict(title='Example',url='https://example.com/')])
    assert page.locator('#quick').is_visible()
    assert page.locator('#quick button').count()==1
    assert page.locator('#quick').evaluate('e=>e.getBoundingClientRect().bottom+window.scrollY') == 118
    page.locator('#shortcutList .remove').click()
    assert page.evaluate('messages.at(-1).action')=='delete_shortcut'
    render(shortcuts=[])
    assert not page.locator('#quick').is_visible()
    assert '런타임 그룹 1개' in page.locator('#stats').inner_text()
    assert page.locator('#autoRelease').get_attribute('aria-checked')=='false'
    page.once('dialog',lambda d:d.accept())
    page.locator('#autoRelease').click()
    assert page.evaluate('messages.at(-1).action')=='auto_release'
    render(auto_release=True)
    assert page.locator('#autoRelease').get_attribute('aria-checked')=='true'
    page.locator('[data-a=engine_tasks]').click()
    assert page.evaluate('messages.at(-1).action')=='engine_tasks'
    page.locator('#memoryToggle').click()
    assert page.evaluate('messages.at(-1).action')=='memory_saver'
    render(memory_saver=False,low_count=0)
    assert page.locator('#memoryToggle').get_attribute('aria-checked')=='false'
    assert page.locator('#autoRelease').is_disabled()
    render(panel=False, light=True)
    assert page.locator('body').get_attribute('class')=='light'
    assert page.locator('body').evaluate("e=>getComputedStyle(e).backgroundColor")=="rgb(231, 231, 231)"
    page.locator('#address').fill('test query')
    page.locator('#address').press('Enter')
    assert page.evaluate('messages.at(-1).value')=='test query'
    page.set_viewport_size({'width':620,'height':400})
    assert page.locator('#address').bounding_box()['width']>80
    render(panel=False,light=False,shortcuts=[])
    assert not errors, errors
    page.set_viewport_size({'width':1280,'height':820})
    render(panel=True,memory_saver=True,auto_release=False,release_minutes=10,low_count=1)
    page.locator('#diagnostics').evaluate('e=>{e.scrollTop=0;e.setSelectionRange(0,0)}')
    page.locator('#shortcutTitle').fill('')
    page.locator('#shortcutUrl').fill('')
    page.evaluate('window.scrollTo(0,0)')
    page.screenshot(path=str(Path(__file__).parent/'preview.png'),full_page=True)
    render(panel=False)
    page.screenshot(path=str(Path(__file__).parent/'frame.png'))
    browser.close()
    print('PASS: frame commands and fallback, feedback IPC/link, redacted diagnostics, memory modes and confirmation, shortcut add/delete, 88/118px layout, theme, narrow viewport; no JS exceptions')
