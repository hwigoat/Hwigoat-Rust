package main

import (
	"crypto/sha256"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestVerifyHash(t *testing.T) {
	p := filepath.Join(t.TempDir(), "test")
	data := []byte("Hwigoat Rust")
	if e := os.WriteFile(p, data, 0600); e != nil {
		t.Fatal(e)
	}
	h := fmt.Sprintf("%x", sha256.Sum256(data))
	if e := verifyHash(p, h+"  test"); e != nil {
		t.Fatal(e)
	}
	if verifyHash(p, strings.Repeat("0", 64)) == nil {
		t.Fatal("accepted incorrect hash")
	}
	if verifyHash(p, "") == nil {
		t.Fatal("accepted empty hash")
	}
}
func TestEnv(t *testing.T) {
	a := envWith([]string{"Path=old", "CARGO_HOME=x", "X=y"}, "PATH=new", "CARGO_HOME=z")
	if len(a) != 3 || strings.Join(a, "|") != "X=y|PATH=new|CARGO_HOME=z" {
		t.Fatalf("bad env: %v", a)
	}
}
func TestAssets(t *testing.T) {
	p := t.TempDir()
	if e := copyAssets(p); e != nil {
		t.Fatal(e)
	}
	for _, n := range []string{"Cargo.toml", "src/main.rs", "src/ui.html"} {
		if !exists(filepath.Join(p, n)) {
			t.Fatalf("missing %s", n)
		}
	}
}

func TestInstallDir(t *testing.T) {
	base := t.TempDir()
	if got := installDir(base); got != base {
		t.Fatal(got)
	}
	old := filepath.Join(base, "0.5.3")
	if e := os.MkdirAll(old, 0755); e != nil {
		t.Fatal(e)
	}
	if e := os.WriteFile(filepath.Join(old, "Hwigoat Rust.exe"), []byte("old"), 0600); e != nil {
		t.Fatal(e)
	}
	if got := installDir(base); got != old {
		t.Fatal(got)
	}
	if e := os.WriteFile(filepath.Join(base, "Hwigoat Rust.exe"), []byte("stable"), 0600); e != nil {
		t.Fatal(e)
	}
	if got := installDir(base); got != base {
		t.Fatal(got)
	}
}
func TestPatchPreservesBackup(t *testing.T) {
	dir := t.TempDir()
	src := filepath.Join(dir, "new.exe")
	dst := filepath.Join(dir, "old.exe")
	for p, v := range map[string]string{src: "new", dst: "old"} {
		if e := os.WriteFile(p, []byte(v), 0600); e != nil {
			t.Fatal(e)
		}
	}
	if e := replaceBinary(src, dst); e != nil {
		t.Fatal(e)
	}
	for p, v := range map[string]string{dst: "new", dst + ".previous": "old"} {
		b, e := os.ReadFile(p)
		if e != nil || string(b) != v {
			t.Fatalf("%s: %s %v", p, b, e)
		}
	}
	if e := copyAtomic(dst+".previous", dst); e != nil {
		t.Fatal(e)
	}
	b, e := os.ReadFile(dst)
	if e != nil || string(b) != "old" {
		t.Fatalf("rollback: %s %v", b, e)
	}
	if e := replaceBinary(src+"missing", dst); e == nil {
		t.Fatal("accepted missing source")
	}
	b, _ = os.ReadFile(dst)
	if string(b) != "old" {
		t.Fatal("modified existing binary after failure")
	}
}
func TestReuseLock(t *testing.T) {
	root := t.TempDir()
	old := filepath.Join(root, "build-v0.5.3")
	proj := filepath.Join(root, "build-current")
	for _, p := range []string{old, proj} {
		if e := os.MkdirAll(p, 0755); e != nil {
			t.Fatal(e)
		}
	}
	content := "[[package]]\nname = \"hwigoat-rust\"\nversion = \"0.5.3\"\n\n[[package]]\nname = \"other\"\nversion = \"0.5.3\"\n"
	if e := os.WriteFile(filepath.Join(old, "Cargo.lock"), []byte(content), 0600); e != nil {
		t.Fatal(e)
	}
	if e := reuseLock(root, proj); e != nil {
		t.Fatal(e)
	}
	got, e := os.ReadFile(filepath.Join(proj, "Cargo.lock"))
	if e != nil || string(got) != strings.Replace(content, "0.5.3", version, 1) {
		t.Fatalf("%s %v", got, e)
	}
}

func TestBrowserPaths(t *testing.T) {
	base, root := filepath.Join("local", "Programs", "Hwigoat Rust"), filepath.Join("local", "HwigoatRustSetup")
	got := browserPaths(base, root)
	if len(got) != 7 {
		t.Fatalf("unexpected paths: %v", got)
	}
	for _, p := range []string{filepath.Join(base, "Hwigoat Rust.exe"), filepath.Join(base, "0.5.3", "Hwigoat Rust.exe"), filepath.Join(root, "target", target, "release", "hwigoat-rust.exe")} {
		found := false
		for _, x := range got {
			if x == p {
				found = true
			}
		}
		if !found {
			t.Fatal("missing browser path", p)
		}
	}
	for _, p := range got {
		if strings.Contains(strings.ToLower(p), "msedgewebview2") {
			t.Fatal("shared runtime must not be closed")
		}
	}
}

func TestSmokeMarker(t *testing.T) {
	if e := verifySmokeMarker("UI IPC and content DOM verified\nversion=" + version + "\n"); e != nil {
		t.Fatal(e)
	}
	for _, x := range []string{"UI IPC and content DOM verified\n", "UI IPC and content DOM verified\nversion=1.0.0\n", "version=" + version + "\n"} {
		if verifySmokeMarker(x) == nil {
			t.Fatal("accepted stale/invalid marker", x)
		}
	}
}
func TestMultiPathTransaction(t *testing.T) {
	d := t.TempDir()
	src := filepath.Join(d, "new.exe")
	base := filepath.Join(d, "app")
	a := filepath.Join(base, "Hwigoat Rust.exe")
	b := filepath.Join(base, "0.5.3", "Hwigoat Rust.exe")
	for p, v := range map[string]string{src: "new", a: "oldA", b: "oldB"} {
		if e := os.MkdirAll(filepath.Dir(p), 0755); e != nil {
			t.Fatal(e)
		}
		if e := os.WriteFile(p, []byte(v), 0600); e != nil {
			t.Fatal(e)
		}
	}
	check := func(p, want string) {
		t.Helper()
		v, e := os.ReadFile(p)
		if e != nil || string(v) != want {
			t.Fatalf("%s: %q %v", p, v, e)
		}
	}
	paths := installTargets(base)
	if len(paths) != 2 {
		t.Fatal(paths)
	}
	if e := patchTransaction(src, paths, func() error { return fmt.Errorf("simulated verification failure") }); e == nil {
		t.Fatal("expected error")
	}
	check(a, "oldA")
	check(b, "oldB")
	if e := patchTransaction(src, paths, func() error { return nil }); e != nil {
		t.Fatal(e)
	}
	check(a, "new")
	check(b, "new")
	check(a+".previous", "oldA")
	check(b+".previous", "oldB")
	if e := patchTransaction(src, paths, func() error { return nil }); e != nil {
		t.Fatal(e)
	}
	check(a+".previous", "oldA")
	check(b+".previous", "oldB")
}
func TestFreshRollback(t *testing.T) {
	d := t.TempDir()
	src := filepath.Join(d, "new.exe")
	dst := filepath.Join(d, "app", "Hwigoat Rust.exe")
	if e := os.WriteFile(src, []byte("new"), 0600); e != nil {
		t.Fatal(e)
	}
	if e := patchTransaction(src, []string{dst}, func() error { return fmt.Errorf("fail") }); e == nil {
		t.Fatal("expected error")
	}
	if exists(dst) {
		t.Fatal("new file remained after rollback")
	}
}
