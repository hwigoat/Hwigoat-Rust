#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
use std::{cell::{Cell,RefCell}, fs, io::Write, path::{Path, PathBuf}, sync::mpsc, thread, time::{Duration, Instant}};
use serde::{Serialize,Deserialize};
use tao::{dpi::{LogicalSize,LogicalPosition}, event::{Event,WindowEvent}, event_loop::{ControlFlow,EventLoopBuilder,EventLoopProxy}, window::{Window,WindowBuilder,Icon}};
use wry::{WebViewBuilderExtWindows,WebViewExtWindows,WebView,WebViewBuilder,WebContext,Rect,NewWindowResponse,PageLoadEvent};
use tao::platform::windows::WindowBuilderExtWindows;
const FEEDBACK:&str="https://discord.com/channels/1213126669385338920/1575778721946796062";
const HOME:&str="https://www.google.com/";
const BAR:u32=88;
const SHORTCUT_BAR:u32=30;
use windows_core::Interface;
use webview2_com::Microsoft::Web::WebView2::Win32::{ICoreWebView2_19, ICoreWebView2_8, ICoreWebView2_6, COREWEBVIEW2_MEMORY_USAGE_TARGET_LEVEL_LOW, COREWEBVIEW2_MEMORY_USAGE_TARGET_LEVEL_NORMAL};
fn default_true()->bool {true}
fn release_delay(minutes:u64)->Duration{Duration::from_secs(match minutes{3=>180,30=>1800,_=>600})}
const TEST_URL:&str="hwigoat-test://localhost/";
const TEST_HTML:&str="<!doctype html><html><head><meta charset=utf-8><title>Hwigoat engine test</title></head><body><main id=engine-test>HWIGOAT_RENDER_OK</main></body></html>";
fn trace(s:&str) {
    if let Some(mark)=std::env::var_os("HWIGOAT_SMOKE_FILE") {
        if let Ok(mut f)=fs::OpenOptions::new().create(true).append(true).open(PathBuf::from(mark).with_extension("log")) {
            let _=writeln!(f,"{s}");
        }
    }
}
fn test_origin(s:&str)->bool {matches!(s,"hwigoat-test://localhost/"|"https://hwigoat-test.localhost/"|"hwigoat-test://localhost"|"https://hwigoat-test.localhost")}

#[derive(Clone,Serialize,Deserialize)] struct Entry {url:String,title:String}
#[derive(Clone,Serialize,Deserialize)] #[serde(default)] struct Saved {tabs:Vec<Entry>,active:usize,bookmarks:Vec<Entry>,history:Vec<Entry>,light:bool,shortcuts:Vec<Entry>,memory_saver:bool, auto_release:bool, release_minutes:u64, native_frame:bool}
impl Default for Saved {fn default()->Self{Self{tabs:vec![],active:0,bookmarks:vec![],history:vec![],light:false,shortcuts:vec![],memory_saver:default_true(),auto_release:false,release_minutes:10,native_frame:false}}}
#[derive(Deserialize)] struct Command {action:String, #[serde(default)] value:String, #[serde(default)] id:u64}
#[derive(Debug)] enum Msg {Command(String),Title(u64,String),Loaded(u64,String),Popup(u64,String),Download(u64,bool), DownloadStart(u64), Probe(bool,String), UiLoaded(String)}
struct Tab {id:u64,entry:Entry,private:bool,view:Option<WebView>,zoom:f64,low:Cell<Option<bool>>,shown:Cell<Option<bool>>, hidden_since:Cell<Option<Instant>>, downloads:u32}
struct App {chrome:WebView,tabs:Vec<Tab>,ctx:WebContext,window:Window,active:usize,next:u64,saved:Saved,closed:Vec<Entry>,panel:bool,proxy:EventLoopProxy<Msg>,notice:String, last_ui:RefCell<String>, save_due:Option<Instant>, save_tx:Option<mpsc::Sender<Saved>>, save_thread:Option<thread::JoinHandle<()>>, last_layout:Cell<Option<(u32,u32,u64,u32,bool)>>}
fn allowed(s:&str)->bool {url::Url::parse(s).map(|u|matches!(u.scheme(),"http"|"https") && u.host_str().is_some() && u.username().is_empty() && u.password().is_none()).unwrap_or(false)}
fn normalized_http(s: &str) -> Option<String> {
    let u = url::Url::parse(s).ok()?;
    if matches!(u.scheme(), "http" | "https") && u.host_str().is_some()
        && u.username().is_empty() && u.password().is_none() {
        Some(u.to_string())
    } else { None }
}
fn address(s: &str) -> String {
    let s = s.trim();
    if let Some(u) = normalized_http(s) { return u; }
    if !s.contains(char::is_whitespace) && (s.contains('.') || s.starts_with("localhost")) && !s.contains("://") {
        if let Some(u) = normalized_http(&format!("https://{s}")) { return u; }
    }
    let mut u = url::Url::parse("https://www.google.com/search").unwrap();
    u.query_pairs_mut().append_pair("q", s);
    u.to_string()
}
fn rect(w:&Window,top:u32,height:Option<u32>)->Rect {let s=w.inner_size().to_logical::<u32>(w.scale_factor());Rect{position:LogicalPosition::new(0,top as i32).into(),size:LogicalSize::new(s.width.max(1),height.unwrap_or(s.height.saturating_sub(top)).max(1)).into()}}
impl App {
fn add(&mut self,e:Entry,private:bool){if self.tabs.len()>=80{self.notice="Tab limit reached (80)".into();return;}let id=self.next;self.next+=1;self.tabs.push(Tab{id,entry:e,private,view:None,zoom:1.,low:Cell::new(None),shown:Cell::new(None),hidden_since:Cell::new(None),downloads:0});self.active=self.tabs.len()-1;}
fn show(&mut self){if self.tabs.is_empty(){self.add(Entry{url:HOME.into(),title:"New tab".into()},false);} if self.tabs[self.active].view.is_none(){let bar=self.bar();let t=&self.tabs[self.active];let id=t.id;let p=self.proxy.clone();let q=p.clone();let r=p.clone();let d=p.clone();let ds=p.clone();let builder=WebViewBuilder::new_with_web_context(&mut self.ctx).with_incognito(t.private);let builder=if t.private{builder}else{builder.with_environment(self.chrome.environment())};let builder=if std::env::var_os("HWIGOAT_SMOKE_FILE").is_some(){builder.with_https_scheme(true).with_custom_protocol("hwigoat-test".into(),|_,_|{trace("Test protocol requested");wry::http::Response::builder().header("Content-Type","text/html; charset=utf-8").body(std::borrow::Cow::Borrowed(TEST_HTML.as_bytes())).unwrap()}).with_url(TEST_URL)}else{builder.with_url(&t.entry.url)};trace("Creating content WebView");let result=builder.with_bounds(rect(&self.window,bar,None)).with_devtools(false).with_focused(false).with_hotkeys_zoom(true).with_download_started_handler(move |_,_|{let _=ds.send_event(Msg::DownloadStart(id));true}).with_download_completed_handler(move |_,_,ok|{let _=d.send_event(Msg::Download(id,ok));}).with_permission_handler(|_|wry::PermissionResponse::Deny).with_navigation_handler(|u|{if std::env::var_os("HWIGOAT_SMOKE_FILE").is_some(){trace(&format!("Test navigation: {u}"));test_origin(&u)||u=="about:blank"}else{allowed(&u)}}).with_new_window_req_handler(move |u,_|{if allowed(&u){let _=p.send_event(Msg::Popup(id,u));}NewWindowResponse::Deny}).with_document_title_changed_handler(move |s|{let _=q.send_event(Msg::Title(id,s));}).with_on_page_load_handler(move |event,u|{if matches!(event,PageLoadEvent::Finished){let _=r.send_event(Msg::Loaded(id,u));}}).build_as_child(&self.window);match result{Ok(v)=>{trace("Content WebView created");let _=v.zoom(self.tabs[self.active].zoom);self.tabs[self.active].view=Some(v);self.tabs[self.active].low.set(None);self.tabs[self.active].shown.set(None);},Err(e)=>{trace(&format!("Content creation failed: {e}"));self.notice=format!("Engine error: {e}");self.panel=true;if std::env::var_os("HWIGOAT_SMOKE_FILE").is_some(){std::process::exit(3);}}}}
self.layout();self.sync();}
fn bar(&self)->u32 { BAR + if self.saved.shortcuts.is_empty(){0}else{SHORTCUT_BAR} }
fn layout(&self){
    let bar=self.bar();
    let size=self.window.inner_size();
    let key=(size.width,size.height,self.window.scale_factor().to_bits(),bar,self.panel);
    let resized=self.last_layout.get()!=Some(key);
    if resized && self.chrome.set_bounds(rect(&self.window,0,if self.panel{None}else{Some(bar)})).is_ok(){self.last_layout.set(Some(key));}
    for(i,t)in self.tabs.iter().enumerate(){if let Some(v)=&t.view{
        let visible=i==self.active&&!self.panel;
        if i==self.active {t.hidden_since.set(None);} else if t.hidden_since.get().is_none(){t.hidden_since.set(Some(Instant::now()));}
        // Hide before applying the low-memory hint; restore before showing.
        if !visible && t.shown.get()!=Some(false){if v.set_visible(false).is_ok(){t.shown.set(Some(false));}}
        // Do not lower the active tab just because the settings panel covers it.
        let low=self.saved.memory_saver&&i!=self.active&&t.downloads==0&&quiet_view(v);
        if t.low.get()!=Some(low){
            match v.webview().cast::<ICoreWebView2_19>() {
                Ok(core)=>{let level=if low{COREWEBVIEW2_MEMORY_USAGE_TARGET_LEVEL_LOW}else{COREWEBVIEW2_MEMORY_USAGE_TARGET_LEVEL_NORMAL};
                    if unsafe{core.SetMemoryUsageTargetLevel(level)}.is_ok(){t.low.set(Some(low));}else{t.low.set(None);}
                },Err(_)=>{t.low.set(None);}
            }
        }
        // Hidden controllers do not need resize work; resize before first display.
        if visible && (resized||t.shown.get()!=Some(true)){
            if v.set_bounds(rect(&self.window,bar,None)).is_err(){self.last_layout.set(None);}
        }
        if visible && t.shown.get()!=Some(true){if v.set_visible(true).is_ok(){t.shown.set(Some(true));}}
    }}
}
fn release_background(&mut self, automatic:bool){
    let mut released=0;
    let mut skipped=0;
    for (i,t) in self.tabs.iter_mut().enumerate(){
        if i==self.active || t.private || t.view.is_none(){continue;}
        if automatic && !t.hidden_since.get().map(|at|at.elapsed()>=release_delay(self.saved.release_minutes)).unwrap_or(false){continue;}
        if t.downloads>0 || t.shown.get()!=Some(false) || !quiet_view(t.view.as_ref().unwrap()){skipped+=1;continue;}
        // Releasing the controller permits actual reclamation, not just a working-set trim.
        t.view.take();t.low.set(None);t.shown.set(None);t.hidden_since.set(None);released+=1;
    }
    if released>0 || !automatic {self.notice=format!("Released {released} inactive tabs; protected {skipped}. Reload on selection.");self.sync();}
}
fn engine_groups(&self)->usize{
    let mut pids=std::collections::HashSet::new();
    if let Some(pid)=browser_pid(&self.chrome){pids.insert(pid);}
    for t in &self.tabs{if let Some(v)=&t.view{if let Some(pid)=browser_pid(v){pids.insert(pid);}}}
    pids.len()
}
fn sync(&self){
    let tabs:Vec<_>=self.tabs.iter().map(|t|serde_json::json!({"id":t.id,"title":t.entry.title,"url":t.entry.url,"private":t.private,"sleep":t.view.is_none(),"low":t.low.get()==Some(true)})).collect();
    let active=self.tabs.get(self.active);
    let (bookmarks,history):(&[Entry],&[Entry])=if self.panel{(&self.saved.bookmarks,&self.saved.history)}else{(&[],&[])};
    let data=serde_json::json!({"tabs":tabs,"active":active.map(|t|t.id),"url":active.map(|t|t.entry.url.as_str()).unwrap_or(""),"bookmarks":bookmarks,"history":history,"light":self.saved.light,"notice":self.notice,"panel":self.panel,"shortcuts":self.saved.shortcuts,"memory_saver":self.saved.memory_saver,"auto_release":self.saved.auto_release,"release_minutes":self.saved.release_minutes,"native_frame":self.window.is_decorated(),"maximized":self.window.is_maximized(),"engine_groups":if self.panel{self.engine_groups()}else{0},"loaded":self.tabs.iter().filter(|t|t.view.is_some()).count(),"low_count":self.tabs.iter().filter(|t|t.view.is_some()&&t.low.get()==Some(true)).count()}).to_string();
    if *self.last_ui.borrow()==data{return;}
    if self.chrome.evaluate_script(&format!("if(typeof window.renderState==='function') window.renderState({data})")).is_ok(){*self.last_ui.borrow_mut()=data;}
}
fn invalidate_ui(&self){self.last_ui.borrow_mut().clear();}
fn save(&mut self){if self.save_tx.is_some() && self.save_due.is_none(){self.save_due=Some(Instant::now()+Duration::from_millis(350));}}
fn flush_save(&mut self){
    self.save_due=None;
    if let Some(tx)=&self.save_tx {
        self.saved.active=self.tabs.iter().take(self.active).filter(|t|!t.private).count().min(self.tabs.iter().filter(|t|!t.private).count().saturating_sub(1));
        self.saved.tabs=self.tabs.iter().filter(|t|!t.private).map(|t|t.entry.clone()).collect();
        if tx.send(self.saved.clone()).is_err(){self.notice="Session writer unavailable".into();self.sync();}
    }
}
fn finish_save(&mut self){self.flush_save();self.save_tx.take();if let Some(worker)=self.save_thread.take(){let _=worker.join();}}
fn command(&mut self,c:Command){self.notice.clear();match c.action.as_str(){"ready"=>{},"new"|"private"=>{self.add(Entry{url:HOME.into(),title:"New tab".into()},c.action=="private");self.panel=false;},"select"=>{if let Some(i)=self.tabs.iter().position(|t|t.id==c.id){self.active=i;}self.panel=false;},"close"=>{if let Some(i)=self.tabs.iter().position(|t|t.id==c.id){let t=self.tabs.remove(i);if !t.private{self.closed.push(t.entry);if self.closed.len()>80{self.closed.remove(0);}}if i<self.active{self.active-=1;}self.active=self.active.min(self.tabs.len().saturating_sub(1));}},"restore"=>{if let Some(e)=self.closed.pop(){self.add(e,false);self.panel=false;}},"navigate"=>{let u=address(&c.value);let t=&mut self.tabs[self.active];t.entry.url=u.clone();t.entry.title=u.clone();if let Some(v)=&t.view{if let Err(e)=v.load_url(&u){self.notice=e.to_string();}}self.panel=false;},"home"=>{let t=&mut self.tabs[self.active];t.entry.url=HOME.into();if let Some(v)=&t.view{let _=v.load_url(HOME);}self.panel=false;},"back"|"forward"|"reload"|"zoom_in"|"zoom_out"|"zoom_reset"=>{let t=&mut self.tabs[self.active];if let Some(v)=&t.view{let _=match c.action.as_str(){"back"=>v.go_back(),"forward"=>v.go_forward(),"reload"=>v.reload(),_=>{t.zoom=match c.action.as_str(){"zoom_in"=>(t.zoom+0.1).min(3.),"zoom_out"=>(t.zoom-0.1).max(0.5),_=>1.};v.zoom(t.zoom)}};}},"bookmark"=>{let t=&self.tabs[self.active];if !t.private&&!self.saved.bookmarks.iter().any(|e|e.url==t.entry.url){self.saved.bookmarks.push(t.entry.clone());self.notice="Bookmark saved".into();}},"delete_bookmark"=>self.saved.bookmarks.retain(|e|e.url!=c.value),
"add_shortcut"=>{let t=&self.tabs[self.active];if !t.private && allowed(&t.entry.url) && self.saved.shortcuts.len()<100 && !self.saved.shortcuts.iter().any(|e|e.url==t.entry.url){self.saved.shortcuts.push(t.entry.clone());self.notice="Shortcut added".into();}},
"custom_shortcut"=>{if let Ok(e)=serde_json::from_str::<Entry>(&c.value){let raw=e.url.trim();let candidate=normalized_http(raw).or_else(||if !raw.contains("://")&&!raw.contains(char::is_whitespace)&&(raw.contains('.')||raw.starts_with("localhost")){normalized_http(&format!("https://{raw}"))}else{None});if let Some(u)=candidate{if self.saved.shortcuts.len()<100&&!self.saved.shortcuts.iter().any(|x|x.url==u){let title:String=e.title.trim().chars().take(80).collect();self.saved.shortcuts.push(Entry{title:if title.is_empty(){u.clone()}else{title},url:u});self.notice="Shortcut added".into();}}else{self.notice="Invalid shortcut URL".into();}}},
"delete_shortcut"=>self.saved.shortcuts.retain(|e|e.url!=c.value),
"memory_saver"=>{self.saved.memory_saver=!self.saved.memory_saver;if !self.saved.memory_saver{self.saved.auto_release=false;}},
"auto_release"=>self.saved.auto_release=!self.saved.auto_release,
"memory_mode"=>match c.value.as_str(){"standard"=>{self.saved.memory_saver=false;self.saved.auto_release=false;},"balanced"=>{self.saved.memory_saver=true;self.saved.auto_release=false;},"aggressive"=>{self.saved.memory_saver=true;self.saved.auto_release=true;},_=>{}},
"release_minutes"=>{if let Ok(n)=c.value.parse::<u64>(){if matches!(n,3|10|30){self.saved.release_minutes=n;}}},
"native_frame"=>{self.saved.native_frame=!self.window.is_decorated();self.window.set_decorations(self.saved.native_frame);},
"feedback"=>{self.notice=if open_feedback(){"Discord feedback opened in your default browser".into()}else{"Could not open Discord. Copy the feedback link from Settings.".into()};},

"engine_tasks"=>{match self.chrome.webview().cast::<ICoreWebView2_6>(){Ok(core)=>{if unsafe{core.OpenTaskManagerWindow()}.is_err(){self.notice="Engine task manager unavailable".into();}},Err(_)=>self.notice="Engine task manager unavailable".into()}},
"clear_history"=>self.saved.history.clear(),"panel"=>self.panel=!self.panel,"theme"=>self.saved.light=!self.saved.light,"sleep"=>self.release_background(false),_=>{}}self.show();self.save();}
}
fn browser_pid(v:&WebView)->Option<u32>{let mut pid=0u32;unsafe{v.webview().BrowserProcessId(&mut pid)}.ok()?;if pid==0{None}else{Some(pid)}}
fn quiet_view(v:&WebView)->bool{
    // Fail closed if the runtime does not expose an audio state.
    let Ok(core)=v.webview().cast::<ICoreWebView2_8>() else{return false;};
    let mut playing=Default::default();
    unsafe{core.IsDocumentPlayingAudio(&mut playing)}.is_ok() && !playing.as_bool()
}
#[link(name="shell32")] extern "system" {fn SetCurrentProcessExplicitAppUserModelID(id:*const u16)->i32;fn ShellExecuteW(hwnd:isize,operation:*const u16,file:*const u16,parameters:*const u16,directory:*const u16,show:i32)->isize;}
fn open_feedback()->bool{
    let verb:Vec<u16>="open".encode_utf16().chain(Some(0)).collect();
    let url:Vec<u16>=FEEDBACK.encode_utf16().chain(Some(0)).collect();
    unsafe{ShellExecuteW(0,verb.as_ptr(),url.as_ptr(),std::ptr::null(),std::ptr::null(),1)>32}
}
fn set_app_identity(){let id:Vec<u16>="Hwigoat.Rust.Browser".encode_utf16().chain(Some(0)).collect();let hr=unsafe{SetCurrentProcessExplicitAppUserModelID(id.as_ptr())};if hr<0{trace(&format!("AppUserModelID HRESULT {hr:#x}"));}}
fn main(){std::panic::set_hook(Box::new(|info|{trace(&format!("PANIC: {info}"));let base=std::env::var_os("LOCALAPPDATA").map(PathBuf::from).unwrap_or_else(std::env::temp_dir);let _=fs::write(base.join("HwigoatRust-error.log"),format!("{info}"));}));if let Err(e)=run(){let base=std::env::var_os("LOCALAPPDATA").map(PathBuf::from).unwrap_or_else(std::env::temp_dir);let msg=format!("Hwigoat Rust could not start: {e}");trace(&msg);let _=fs::write(base.join("HwigoatRust-error.log"),&msg);if std::env::var_os("HWIGOAT_SMOKE_FILE").is_none(){show_error(&msg);}std::process::exit(1);}}
#[link(name="user32")] extern "system" {fn MessageBoxW(hwnd:isize,text:*const u16,caption:*const u16,kind:u32)->i32;}
fn show_error(msg:&str){let text:Vec<u16>=msg.encode_utf16().chain(Some(0)).collect();let title:Vec<u16>="Hwigoat Rust".encode_utf16().chain(Some(0)).collect();unsafe{MessageBoxW(0,text.as_ptr(),title.as_ptr(),0x10);}}
#[link(name="kernel32")] extern "system" {fn CreateMutexW(attributes:*mut std::ffi::c_void,owner:i32,name:*const u16)->isize;fn GetLastError()->u32;fn CloseHandle(handle:isize)->i32;}
struct InstanceGuard(isize);
impl Drop for InstanceGuard{fn drop(&mut self){unsafe{CloseHandle(self.0);}}}
fn lock_instance(base:&Path)->Result<InstanceGuard,Box<dyn std::error::Error>>{
    use std::hash::{Hash,Hasher};
    let mut hasher=std::collections::hash_map::DefaultHasher::new();
    base.to_string_lossy().to_lowercase().hash(&mut hasher);
    let name:Vec<u16>=format!("Local\\HwigoatRustProfile-{:016x}",hasher.finish()).encode_utf16().chain(Some(0)).collect();
    let (handle,error)=unsafe{let h=CreateMutexW(std::ptr::null_mut(),0,name.as_ptr());(h,GetLastError())};
    if handle==0{return Err(std::io::Error::from_raw_os_error(error as i32).into());}
    let guard=InstanceGuard(handle);
    if error==183{return Err("Hwigoat Rust is already open for this profile".into());}
    Ok(guard)
}
fn ui_origin(s:&str)->bool {matches!(s,"https://hwigoat.localhost/"|"hwigoat://localhost/"|"https://hwigoat.localhost"|"hwigoat://localhost")}

fn write_session(path:&Path,saved:&Saved)->Result<(),Box<dyn std::error::Error>>{
    let bytes=serde_json::to_vec(saved)?;
    let temp=path.with_extension("tmp");
    let mut file=fs::File::create(&temp)?;
    file.write_all(&bytes)?;
    file.sync_all()?;
    drop(file);
    fs::rename(temp,path)?;
    Ok(())
}
fn start_writer(path:PathBuf)->(mpsc::Sender<Saved>,thread::JoinHandle<()>) {
    let (tx,rx)=mpsc::channel::<Saved>();
    let worker=thread::spawn(move||{
        while let Ok(mut latest)=rx.recv(){
            // Coalesce queued snapshots while disk is busy; final snapshot wins.
            while let Ok(newer)=rx.try_recv(){latest=newer;}
            if let Err(e)=write_session(&path,&latest){let _=fs::write(path.with_extension("error.log"),format!("Session save failed: {e}"));}
        }
    });
    (tx,worker)
}
fn run()->Result<(),Box<dyn std::error::Error>> {
    let smoke=std::env::var_os("HWIGOAT_SMOKE_FILE").map(PathBuf::from);
    let launch_mark=if smoke.is_none(){std::env::var_os("HWIGOAT_LAUNCH_MARK").filter(|s|!s.is_empty()).map(PathBuf::from)}else{None};
    trace(concat!("Starting Rust application ", env!("CARGO_PKG_VERSION")));
    let base=if let Some(ref m)=smoke {m.with_extension("profile")} else {PathBuf::from(std::env::var("LOCALAPPDATA")?).join("HwigoatRust")};
    fs::create_dir_all(&base)?;
    let instance=lock_instance(&base)?;
    let path=base.join("session.json");
    let saved:Saved=match fs::read(&path){
        Ok(b)=>match serde_json::from_slice(&b){Ok(s)=>s,Err(e)=>{let backup=path.with_extension("invalid.json");if backup.exists(){return Err(format!("Session unreadable: {e}; existing backup must be preserved").into());}fs::copy(&path,backup)?;Saved::default()}},
        Err(e) if e.kind()==std::io::ErrorKind::NotFound=>Saved::default(),
        Err(e)=>return Err(e.into())
    };
    set_app_identity();
    let ev=EventLoopBuilder::<Msg>::with_user_event().build();
    let proxy=ev.create_proxy();
    let p=proxy.clone(); let load_proxy=proxy.clone();
    let app_icon=Icon::from_rgba(include_bytes!("app.rgba").to_vec(),64,64)?;
    let task_icon=Icon::from_rgba(include_bytes!("app.rgba").to_vec(),64,64)?;
    let native_frame=saved.native_frame||std::env::var_os("HWIGOAT_NATIVE_FRAME").is_some();
    let window=WindowBuilder::new().with_decorations(native_frame).with_undecorated_shadow(true).with_title("Hwigoat Rust").with_window_icon(Some(app_icon)).with_taskbar_icon(Some(task_icon)).with_inner_size(LogicalSize::new(1280,820)).with_min_inner_size(LogicalSize::new(620,400)).build(&ev)?;
    trace("Native window created; creating UI WebView");
    // Retain the existing browsing user-data folder; isolate the trusted UI in a named profile.
    let mut shared_ctx=WebContext::new(Some(base.join("web-profile")));
    let chrome=WebViewBuilder::new_with_web_context(&mut shared_ctx)
        .with_profile_name("HwigoatUI")
        .with_https_scheme(true)
        .with_custom_protocol("hwigoat".into(),|_,_|{
            trace("UI protocol requested");
            wry::http::Response::builder().header("Content-Type","text/html; charset=utf-8").body(std::borrow::Cow::Borrowed(include_bytes!("ui.html").as_slice())).unwrap()
        })
        .with_url("hwigoat://localhost/")
        .with_bounds(rect(&window,0,Some(BAR)))
        .with_navigation_handler(|u|{trace(&format!("UI navigation: {u}"));ui_origin(&u)||u=="about:blank"})
        .with_new_window_req_handler(|_,_|NewWindowResponse::Deny)
        .with_devtools(false)
        .with_on_page_load_handler(move |event,u|{if matches!(event,PageLoadEvent::Finished){let _=load_proxy.send_event(Msg::UiLoaded(u));}})
        .with_ipc_handler(move |r|{
            let source=r.uri().to_string();
            if ui_origin(&source) && r.body().len()<16384 {let _=p.send_event(Msg::Command(r.body().clone()));}
            else {trace(&format!("Rejected UI IPC source: {source}"));}
        }).build_as_child(&window)?;
    trace("UI WebView created");
    let entries=saved.tabs.clone();let selected=saved.active;
    let (save_tx,save_thread)=if smoke.is_none(){let (tx,worker)=start_writer(path);(Some(tx),Some(worker))}else{(None,None)};
    let mut app=App{window,chrome,ctx:shared_ctx,tabs:vec![],active:0,next:1,saved,closed:vec![],panel:false,proxy,notice:String::new(),last_ui:RefCell::new(String::new()),save_due:None,save_tx,save_thread,last_layout:Cell::new(None)};
    for e in entries.into_iter().filter(|e|allowed(&e.url)).take(80){app.add(e,false);}
    app.active=selected.min(app.tabs.len().saturating_sub(1));
    // A model exists before the page is initialized; create the second controller only
    // after the native message loop is running, not during initial window construction.
    if app.tabs.is_empty(){app.add(Entry{url:HOME.into(),title:"New tab".into()},false);}
    let mut started=false;
    let mut ready=false;
    let mut ui_ok=false;
    let mut content_ok=false;
    let mut launch_reported=false;
    let mut next_probe=Instant::now();
    let mut next_release=Instant::now()+Duration::from_secs(30);
    let start_time=Instant::now();
    ev.run(move |event,_,flow|{
        let _keep=&instance;
        *flow=if smoke.is_some()||!started {ControlFlow::WaitUntil(Instant::now()+Duration::from_millis(500))}else{ControlFlow::Wait};
        match event {
            Event::WindowEvent{event:WindowEvent::CloseRequested,..}=>{app.finish_save();*flow=ControlFlow::Exit;return;},
            Event::WindowEvent{event:WindowEvent::Resized(_)|WindowEvent::ScaleFactorChanged{..},..}=>{app.layout();app.sync();},
            Event::UserEvent(Msg::UiLoaded(u))=>{trace(&format!("UI load finished: {u}"));app.invalidate_ui();app.sync();},
            Event::UserEvent(Msg::Command(s))=>{
                if let Ok(c)=serde_json::from_str::<Command>(&s){
                    if c.action=="ready" {
                        if !ready{trace("UI IPC ready received");}
                        ready=true;
                        let _=app.chrome.evaluate_script("window.__hwigoatReadyAck=true");
                        app.invalidate_ui();if !started {started=true;app.show();} else {app.sync();}
                    } else if started && smoke.is_none(){
                        match c.action.as_str(){
                            "window_close"=>{app.finish_save();*flow=ControlFlow::Exit;return;},
                            "window_minimize"=>app.window.set_minimized(true),
                            "window_maximize"=>{app.window.set_maximized(!app.window.is_maximized());app.sync();},
                            "window_drag"=>{let _=app.window.drag_window();},
                            _=>app.command(c),
                        }
                    }
                }
            },
            Event::UserEvent(Msg::Popup(id,u))=>{if smoke.is_none(){if let Some(private)=app.tabs.iter().find(|t|t.id==id).map(|t|t.private){app.add(Entry{url:u,title:"New tab".into()},private);app.show();app.save();}}},
            Event::UserEvent(Msg::DownloadStart(id))=>{if let Some(t)=app.tabs.iter_mut().find(|t|t.id==id){t.downloads=t.downloads.saturating_add(1);}app.layout();app.sync();},
            Event::UserEvent(Msg::Download(id,ok))=>{if let Some(t)=app.tabs.iter_mut().find(|t|t.id==id){t.downloads=t.downloads.saturating_sub(1);app.notice=if ok{"Download completed".into()}else{"Download failed or cancelled".into()};}app.layout();app.sync();},
            Event::UserEvent(Msg::Title(id,s))=>{if smoke.is_some(){trace(&format!("Content title: {s}"));}if let Some(t)=app.tabs.iter_mut().find(|t|t.id==id){if t.entry.title!=s{t.entry.title=s;if !t.private{if let Some(h)=app.saved.history.iter_mut().find(|h|h.url==t.entry.url){h.title=t.entry.title.clone();}app.save();}app.sync();}}},
            Event::UserEvent(Msg::Loaded(id,u))=>{if smoke.is_some(){trace(&format!("Content load finished: {u}"));}if allowed(&u){if let Some(t)=app.tabs.iter_mut().find(|t|t.id==id){t.entry.url=u;if !t.private{let e=t.entry.clone();app.saved.history.retain(|x|x.url!=e.url);app.saved.history.insert(0,e);app.saved.history.truncate(500);}}app.sync();app.save();}},
            Event::UserEvent(Msg::Probe(is_ui,result))=>{
                if is_ui && result=="true" && !ui_ok {ui_ok=true;trace("UI DOM and IPC acknowledgement verified");}
                if !is_ui && result=="true" && !content_ok {content_ok=true;trace("Content DOM and JavaScript verified");}
            },
            _=>{}
        }
        // A missing UI handshake must not prevent the ordinary browser from trying to open.
        // Smoke mode still requires a real handshake before reporting success.
        if !started && start_time.elapsed()>=Duration::from_secs(3){trace("Deferred content startup (UI ready not received yet)");started=true;app.show();}
        if smoke.is_none(){
            if !launch_reported && ready && started && app.tabs.get(app.active).and_then(|t|t.view.as_ref()).is_some(){
                if let Some(ref mark)=launch_mark {launch_reported=fs::write(mark,concat!("version=",env!("CARGO_PKG_VERSION"),"\nnormal profile UI IPC and content controller ready\n")).is_ok();}
            }
            if app.save_due.map(|due|Instant::now()>=due).unwrap_or(false){app.flush_save();}
            if started {
                let auto=app.saved.memory_saver&&app.tabs.iter().enumerate().any(|(i,t)|i!=app.active&&!t.private&&t.view.is_some());
                if auto && Instant::now()>=next_release{next_release=Instant::now()+Duration::from_secs(30);app.layout();if app.saved.auto_release{app.release_background(true);}app.sync();}
                let deadline=if auto{Some(app.save_due.map(|d|d.min(next_release)).unwrap_or(next_release))}else{app.save_due};
                *flow=match deadline{Some(due)=>ControlFlow::WaitUntil(due),None=>ControlFlow::Wait};
            }
        }
        if let Some(ref m)=smoke {
            if ready&&ui_ok&&content_ok {
                let ui_pid=browser_pid(&app.chrome);
                let page_pid=app.tabs.get(app.active).and_then(|t|t.view.as_ref()).and_then(browser_pid);
                trace(&format!("Runtime process IDs: UI={ui_pid:?}, content={page_pid:?}"));
                if ui_pid.is_none()||ui_pid!=page_pid{trace("WARNING: shared runtime not confirmed; UI and content rendering passed");}else{trace("Shared runtime verified");}
                trace("All required smoke checks passed");
                if fs::write(m,concat!("UI IPC and content DOM verified\nversion=",env!("CARGO_PKG_VERSION"),"\n")).is_ok(){*flow=ControlFlow::Exit;return;}
                trace("Could not write success marker");std::process::exit(2);
            }
            if Instant::now()>=next_probe {
                next_probe=Instant::now()+Duration::from_secs(1);
                if !ui_ok {
                    let p=app.proxy.clone();
                    if let Err(e)=app.chrome.evaluate_script_with_callback("Boolean(window.__hwigoatReadyAck===true && typeof window.renderState==='function' && document.getElementById('address') && document.querySelector('#tabs .tab') && document.getElementById('feedbackButton') && document.getElementById('windowControls'))",move |r|{let _=p.send_event(Msg::Probe(true,r));}){trace(&format!("UI probe error: {e}"));}
                }
                if !content_ok {if let Some(v)=app.tabs.get(app.active).and_then(|t|t.view.as_ref()){
                    let p=app.proxy.clone();
                    if let Err(e)=v.evaluate_script_with_callback("Boolean(document.title==='Hwigoat engine test' && document.getElementById('engine-test')?.textContent==='HWIGOAT_RENDER_OK')",move |r|{let _=p.send_event(Msg::Probe(false,r));}){trace(&format!("Content probe error: {e}"));}
                }}
            }
            if start_time.elapsed()>=Duration::from_secs(75){trace(&format!("Smoke deadline: ready={ready}, ui_dom={ui_ok}, content_dom={content_ok}"));std::process::exit(4);}
        }
    });
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn session_writer_flushes_latest() {
        let dir=std::env::temp_dir().join(format!("hwigoat-session-test-{}",std::process::id()));
        fs::create_dir_all(&dir).unwrap();
        let path=dir.join("session.json");
        let (tx,worker)=start_writer(path.clone());
        let mut first=Saved::default();
        first.light=false;tx.send(first).unwrap();
        let mut last=Saved::default();last.light=true;tx.send(last).unwrap();
        drop(tx);worker.join().unwrap();
        let saved:Saved=serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
        assert!(saved.light);
        fs::remove_dir_all(dir).unwrap();
    }
    #[test]
    fn legacy_session_defaults() {
        let old:Saved=serde_json::from_str(r#"{"tabs":[],"bookmarks":[{"url":"https://example.com/","title":"Example"}],"light":true}"#).unwrap();
        assert!(old.memory_saver);assert!(!old.auto_release);assert_eq!(old.release_minutes,10);assert!(!old.native_frame);assert!(old.shortcuts.is_empty());assert_eq!(old.bookmarks.len(),1);assert!(old.light);
        let mut s=Saved::default();s.memory_saver=false;s.shortcuts.push(Entry{url:"https://example.com/".into(),title:"Example".into()});
        let restored:Saved=serde_json::from_str(&serde_json::to_string(&s).unwrap()).unwrap();assert!(!restored.memory_saver);assert_eq!(restored.shortcuts.len(),1);
    }
    #[test]
    fn public_beta_defaults_and_delay(){
        assert_eq!(FEEDBACK,"https://discord.com/channels/1213126669385338920/1575778721946796062");
        assert_eq!(release_delay(3),Duration::from_secs(180));
        assert_eq!(release_delay(30),Duration::from_secs(1800));
        assert_eq!(release_delay(0),Duration::from_secs(600));
        assert!(!Saved::default().auto_release);
    }
    #[test]
    fn urls() {
        assert!(allowed("https://example.com"));
        assert!(!allowed("javascript:alert(1)"));
        assert!(!allowed("file:///secret"));
        assert!(!allowed("https://a:b@example.com"));
        assert_eq!(address("example.com"), "https://example.com/");
        assert!(address("hello world").contains("hello+world"));
    }
    #[test]
    fn normalized_addresses() {
        assert_eq!(address("https://example.com"), "https://example.com/");
        assert_eq!(address("  EXAMPLE.COM  "), "https://example.com/");
        assert_eq!(address("http://example.com:80"), "http://example.com/");
        assert_eq!(address("example.com/path?q=1#part"), "https://example.com/path?q=1#part");
        assert_eq!(address("https://example.com/"), "https://example.com/");
    }
    #[test]
    fn search_and_scheme_safety() {
        for input in ["javascript:alert(1)", "file:///secret", "https://a:b@example.com", "hello world"] {
            let result = url::Url::parse(&address(input)).unwrap();
            assert_eq!(result.host_str(), Some("www.google.com"));
            assert_eq!(result.query_pairs().find(|(key, _)| key == "q").unwrap().1.as_ref(), input);
        }
    }
}
