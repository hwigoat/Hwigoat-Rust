fn main() {
    println!("cargo:rerun-if-changed=src/brand.res");
    if std::env::var("CARGO_CFG_TARGET_OS").as_deref() == Ok("windows") && std::env::var("CARGO_CFG_TARGET_ENV").as_deref() == Ok("msvc") {
        let resource = std::path::PathBuf::from(std::env::var_os("CARGO_MANIFEST_DIR").unwrap()).join("src").join("brand.res");
        println!("cargo:rustc-link-arg-bin=hwigoat-rust={}", resource.display());
    }
}
