//go:build !windows

package main

import "os"

func moveReplace(src, dst string) error { return os.Rename(src, dst) }
