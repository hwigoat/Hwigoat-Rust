"""Build temporary monochrome icon and MSVC .res from the former browser emblem.
Not the original Ball Fight symbol. Re-run after replacing icon artwork.
"""
from pathlib import Path
import struct as s
from PIL import Image, ImageDraw
root=Path(__file__).parent/'project/src'
N=1024
im=Image.new('RGBA',(N,N),(0,0,0,0)); d=ImageDraw.Draw(im)
def pts(x): return [(round(a*N/100),round(b*N/100)) for a,b in x]
d.rounded_rectangle((16,16,N-16,N-16),radius=210,fill='#101010')
d.polygon(pts([(12,9),(36,28),(50,20),(64,28),(88,9),(81,49),(68,72),(50,90),(32,72),(19,49)]),fill='#f5f5f5')
d.polygon(pts([(27,38),(44,49),(30,54)]),fill='#101010');d.polygon(pts([(73,38),(56,49),(70,54)]),fill='#101010')
d.line(pts([(40,65),(50,74),(60,65)]),fill='#101010',width=48,joint='curve')
im=im.resize((256,256),Image.Resampling.LANCZOS)
im.save(root/'app.ico',sizes=[(16,16),(24,24),(32,32),(48,48),(64,64),(128,128),(256,256)])
(root/'app.rgba').write_bytes(im.resize((64,64),Image.Resampling.LANCZOS).tobytes())
def pad(b):return b+b'\0'*((-len(b))%4)
def u(t):return (t+'\0').encode('utf-16le')
def block(key,val=b'',kids=b'',typ=0,vlen=None):
    if vlen is None:vlen=len(val)//2 if typ else len(val)
    b=pad(s.pack('<HHH',0,vlen,typ)+u(key))+val
    if kids:b=pad(b)+kids
    return s.pack('<H',len(b))+b[2:]
def children(xs):return b''.join(pad(x) for x in xs)
strings={'CompanyName':'Hwigoat','FileDescription':'Hwigoat Rust','FileVersion':'1.0.2.0','InternalName':'hwigoat-rust','OriginalFilename':'Hwigoat Rust.exe','ProductName':'Hwigoat Rust','ProductVersion':'1.0.2'}
st=block('040904B0',kids=children([block(k,u(v),typ=1) for k,v in strings.items()]),typ=1)
info=block('StringFileInfo',kids=st,typ=1)
var=block('VarFileInfo',kids=block('Translation',s.pack('<HH',0x409,1200)),typ=1)
fixed=s.pack('<13I',0xFEEF04BD,0x10000,0x10000,0x20000,0x10000,0x20000,0x3f,0,0x40004,1,0,0,0)
version=block('VS_VERSION_INFO',fixed,children([info,var]))
def res(t,n,data,lang=0x409,flags=0x1030):
    h=s.pack('<HHHHIHHII',0xffff,t,0xffff,n,0,flags,lang,0,0)
    return s.pack('<II',len(data),8+len(h))+h+pad(data)
b=(root/'app.ico').read_bytes(); _,kind,count=s.unpack_from('<HHH',b)
assert kind==1
grp=s.pack('<HHH',0,1,count); out=res(0,0,b'',0,0)
for i in range(count):
    w,h,c,r,planes,bpp,size,off=s.unpack_from('<BBBBHHII',b,6+16*i)
    out+=res(3,i+1,b[off:off+size]);grp+=s.pack('<BBBBHHIH',w,h,c,r,planes,bpp,size,i+1)
out+=res(14,1,grp)+res(16,1,version)
(root/'brand.res').write_bytes(out)
