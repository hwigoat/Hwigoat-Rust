//go:build !windows

package main

func acquireSetupLock(root string) (func(), error) { return func() {}, nil }
